import { NextRequest, NextResponse } from 'next/server';
import { generateSignal } from '@/lib/signal-engine';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { broker, pair, timeframe, strategy } = body;

    if (!broker || !pair || !timeframe) {
      return NextResponse.json({ error: 'Broker, pair, and timeframe are required' }, { status: 400 });
    }

    console.log(`[API/generate] Generating signal for ${pair} via ${broker}, timeframe: ${timeframe}, strategy: ${strategy || 'Scalping'}`);

    // Generate signal using the real data engine
    const signal = await generateSignal({
      broker,
      pair,
      timeframe,
      strategy: strategy || 'Scalping',
    });

    console.log(`[API/generate] Signal generated: ${signal.direction} @ ${signal.entryPrice} (confidence: ${signal.confidence}%)`);

    // Try to save signal if user is authenticated
    let savedSignal = null;
    const authHeader = request.headers.get('authorization');
    if (authHeader?.startsWith('Bearer ')) {
      const token = authHeader.replace('Bearer ', '');
      const payload = await verifyToken(token);
      if (payload) {
        try {
          savedSignal = await db.signal.create({
            data: {
              userId: payload.userId,
              broker,
              pair,
              pairCategory: signal.pairCategory,
              timeframe,
              direction: signal.direction,
              accuracy: signal.accuracy,
              riskLevel: signal.riskLevel,
              strategy: strategy || 'Scalping',
              rsi: signal.rsi,
              macd: signal.macd,
              macdSignal: signal.macdSignal,
              ma20: signal.ma20,
              ma50: signal.ma50,
              entryPrice: signal.entryPrice,
            },
          });

          await db.user.update({
            where: { id: payload.userId },
            data: { totalTrades: { increment: 1 } },
          });
        } catch (dbError) {
          console.error('[API/generate] Failed to save signal to database:', dbError);
          // Continue without saving — still return the generated signal
        }
      }
    }

    return NextResponse.json({
      id: savedSignal?.id || `sig-${Date.now()}`,
      ...signal,
      broker,
      pair,
      pairCategory: signal.pairCategory,
      timeframe,
      strategy: strategy || 'Scalping',
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('[API/generate] Signal generation error:', error);

    const message = error instanceof Error ? error.message : 'Unknown error';

    // If it's a timeout or network error, provide a more helpful response
    if (message.includes('timed out') || message.includes('fetch') || message.includes('network')) {
      return NextResponse.json(
        { error: 'Market data is temporarily unavailable. Please try again in a moment.' },
        { status: 503 }
      );
    }

    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
