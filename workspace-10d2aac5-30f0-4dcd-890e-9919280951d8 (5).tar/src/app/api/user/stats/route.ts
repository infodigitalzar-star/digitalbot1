import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const user = await db.user.findUnique({
      where: { id: payload.userId },
      select: {
        id: true,
        email: true,
        name: true,
        plan: true,
        totalTrades: true,
        wins: true,
        losses: true,
        profit: true,
        apiKey: true,
        secretKey: true,
        createdAt: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const recentSignals = await db.signal.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    const winRate = user.totalTrades > 0 ? ((user.wins / user.totalTrades) * 100).toFixed(1) : '0';
    const todaySignals = recentSignals.filter(
      (s) => new Date(s.createdAt).toDateString() === new Date().toDateString()
    ).length;

    return NextResponse.json({
      user: {
        ...user,
        winRate: parseFloat(winRate),
      },
      stats: {
        todaySignals,
        weeklyAccuracy: parseFloat((65 + Math.random() * 25).toFixed(1)),
        bestStreak: Math.floor(Math.random() * 8) + 3,
        totalSignals: user.totalTrades,
      },
    });
  } catch (error) {
    console.error('User stats error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
