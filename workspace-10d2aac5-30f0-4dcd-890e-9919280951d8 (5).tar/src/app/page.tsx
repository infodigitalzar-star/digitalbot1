'use client';

import { useEffect, useCallback, useRef, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  Zap, TrendingUp, TrendingDown, Activity, BarChart3, Shield, Clock,
  Volume2, VolumeX, RefreshCw, ChevronDown, User, LogOut,
  Target, Bell, BellOff, Settings, History, DollarSign, Trophy,
  ChevronUp, Copy, Check, Eye, EyeOff, Key, Lock, ArrowUpRight, ArrowDownRight,
  Wifi, WifiOff, Gauge, Coins, Globe, Gem, Landmark, TrendingUpIcon
} from 'lucide-react';
import { useAppStore, type TradingSignal, type ViewType, type PairData } from '@/store/app-store';

// ==================== SOUND UTILITY ====================
function playSignalSound(direction: 'BUY' | 'SELL') {
  try {
    const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    if (direction === 'BUY') {
      oscillator.frequency.setValueAtTime(523.25, audioCtx.currentTime);
      oscillator.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.1);
      oscillator.frequency.setValueAtTime(783.99, audioCtx.currentTime + 0.2);
    } else {
      oscillator.frequency.setValueAtTime(783.99, audioCtx.currentTime);
      oscillator.frequency.setValueAtTime(659.25, audioCtx.currentTime + 0.1);
      oscillator.frequency.setValueAtTime(523.25, audioCtx.currentTime + 0.2);
    }

    oscillator.type = 'sine';
    gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime);
    gainNode.gain.setValueAtTime(0.15, audioCtx.currentTime + 0.3);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.5);

    oscillator.start(audioCtx.currentTime);
    oscillator.stop(audioCtx.currentTime + 0.5);
  } catch (e) {
    console.log('Audio not supported');
  }
}

function playNotificationSound() {
  try {
    const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    oscillator.frequency.setValueAtTime(880, audioCtx.currentTime);
    oscillator.frequency.setValueAtTime(1046.5, audioCtx.currentTime + 0.15);
    oscillator.type = 'sine';
    gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
    oscillator.start(audioCtx.currentTime);
    oscillator.stop(audioCtx.currentTime + 0.3);
  } catch (e) {
    console.log('Audio not supported');
  }
}

// ==================== PARTICLES ====================
function Particles() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return <div className="particles" />;
  }

  const particles = Array.from({ length: 30 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    size: 1 + Math.random() * 2,
    duration: 10 + Math.random() * 20,
    delay: Math.random() * 10,
    opacity: 0.1 + Math.random() * 0.3,
  }));

  return (
    <div className="particles">
      {particles.map((p) => (
        <div
          key={p.id}
          className="particle"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            opacity: p.opacity,
          }}
        />
      ))}
    </div>
  );
}

// ==================== NAVIGATION ====================
const navItems: { id: ViewType; label: string; icon: React.ReactNode }[] = [
  { id: 'signals', label: 'Signals', icon: <Zap size={18} /> },
  { id: 'dashboard', label: 'Dashboard', icon: <BarChart3 size={18} /> },
  { id: 'history', label: 'History', icon: <History size={18} /> },
];

function Navigation() {
  const { currentView, setCurrentView, user } = useAppStore();

  return (
    <nav className="glass-card rounded-2xl p-2 flex gap-1">
      {navItems.map((item) => (
        <button
          key={item.id}
          onClick={() => setCurrentView(item.id)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
            currentView === item.id
              ? 'nav-item-active'
              : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
          }`}
        >
          {item.icon}
          <span className="hidden sm:inline">{item.label}</span>
        </button>
      ))}
    </nav>
  );
}

// ==================== HEADER ====================
function Header() {
  const { soundEnabled, toggleSound, autoRefresh, setAutoRefresh, user, setCurrentView, setToken, setUser } = useAppStore();

  return (
    <header className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#00d4ff] to-[#a855f7] flex items-center justify-center">
            <Zap size={22} className="text-white" />
          </div>
          <div className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-[#22c55e] rounded-full border-2 border-[#050a18] animate-pulse" />
        </div>
        <div>
          <h1 className="text-lg sm:text-xl font-bold tracking-tight">
            <span className="text-[#00d4ff] glow-text-blue">YQT</span>{' '}
            <span className="text-[#a855f7] glow-text-purple">BOT</span>{' '}
            <span className="text-foreground">PRO</span>
          </h1>
          <p className="text-[10px] sm:text-xs text-muted-foreground tracking-widest uppercase">Binary Trading Bot</p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => setAutoRefresh(!autoRefresh)}
          className={`p-2 rounded-lg transition-all duration-300 ${
            autoRefresh ? 'text-[#22c55e]' : 'text-muted-foreground hover:text-foreground'
          }`}
          title={autoRefresh ? 'Auto-refresh ON' : 'Auto-refresh OFF'}
        >
          {autoRefresh ? <Wifi size={18} /> : <WifiOff size={18} />}
        </button>

        <button
          onClick={toggleSound}
          className={`p-2 rounded-lg transition-all duration-300 ${
            soundEnabled ? 'text-[#00d4ff]' : 'text-muted-foreground hover:text-foreground'
          }`}
          title={soundEnabled ? 'Sound ON' : 'Sound OFF'}
        >
          {soundEnabled ? <Volume2 size={18} /> : <VolumeX size={18} />}
        </button>

        {user ? (
          <div className="flex items-center gap-2">
            <span className="hidden md:flex items-center gap-1.5 text-xs text-muted-foreground">
              <div className="w-2 h-2 rounded-full bg-[#22c55e] animate-pulse" />
              {user.name}
            </span>
            <button
              onClick={() => {
                setToken(null);
                setUser(null);
                setCurrentView('signals');
                if (typeof window !== 'undefined') {
                  localStorage.removeItem('yqt_token');
                  localStorage.removeItem('yqt_user');
                }
              }}
              className="p-2 rounded-lg text-muted-foreground hover:text-[#ef4444] transition-all duration-300"
              title="Logout"
            >
              <LogOut size={18} />
            </button>
          </div>
        ) : null}
      </div>
    </header>
  );
}

// ==================== CONFIGURATION PANEL ====================
const brokers = [
  'Quotex',
  'Binomo',
  'Pocket Option',
  'IQ Option',
  'Olymp Trade',
  'Expert Option',
  'RaceOption',
  'Binary.com',
  'Deriv',
  'Nadex',
  'PocketOption',
  'OneTwoTrade',
  '365Trading',
  'OptionFair',
  'Banc De Binary',
  'TradeRush',
  'AnyOption',
  'StockPair',
  'Dragon Options',
  'Tradesolid',
  '24Option',
  'OptionBit',
  'Boss Capital',
  'Brokers King',
  'CherryTrade',
  'CMC Markets Binary',
  'CTOption',
  'Daily Binary Profits',
  'DB Markets',
  'Eztrader',
  'Finrally',
  'GOptions',
  'GTOptions',
  'HelloBinary',
  'Interactive Option',
  'JMB Profit Machine',
  'KayaFX',
  'LBinary',
  'MarketsKing',
  'MaxOptions',
  'Mikes Auto Trader',
  'MOption',
  'NatureForex',
  'No1Options',
  'Opteck',
  'OptionMint',
  'OptionStars',
  'OptionTime',
  'OptionWeb',
  'Orion Code',
  'OX Markets',
  'ParagonEX',
  'Pentland Capital',
  'PFX Financial',
  'PlusOption',
  'Porter Finance',
  'PowerOption',
  'Profiting With Binary',
  'RBOptions',
  'Redwood Options',
  'Safe24Options',
  'Secured Options',
  'SignalPush',
  'Skyline Markets',
  'SOS Options',
  'Stockpair',
  'SuperOptions',
  'Swiss Binary Options',
  'TD Ameritrade',
  'TenTrade',
  'The Bonus Busters',
  'TopOption',
  'TraderXP',
  'Tradologic',
  'TrioMarkets',
  'TrOption',
  'TuringTrader',
  'UBinary',
  'United Options',
  'Verum Option',
  'VIP Binary',
  'Wealth Recovery International',
  'WheelofFortune',
  'WinOptions',
  'WorldWideMarkets',
  'XPMarkets',
  'Your Legacy Club',
  'ZoomTrader',
  'Binary Capital Markets',
  'Binary Brokerz',
  'Binary International',
  'Binary Options Trading Signals',
  'Binary Reverse',
  'Binarymate',
  'BinaryOnline',
  'BinaryTilt',
  'Bloombex Options',
  'Boss Capital Pro',
  'Bull Option',
  'Capital Option',
  'Centument',
  'Citrades',
  'Climax Capital',
  'Cryo Binary',
  'Dr Binary',
  'Drexel Code',
  'Easy XP',
  'eXbino',
  'Fair Binary Options',
  'Fast Cash Biz',
  'Fintech LTD',
  'Forex Binary',
  'Free Money System',
  'GB Binary',
  'Global Option',
  'Golden Binary',
  'Green Machine Binary',
  'HighLow',
  'Hybrid Reserve',
  'Ivory Option',
  'KeyOption',
  'Lexington Code',
  'Lucky 350',
  'Magnum Options',
  'Millionaire Blueprint',
  'Monaco Treasure',
  'Monster Profits',
  'Niche Trading',
  'Nova Code',
  'Option Bot',
  'Option FM',
  'Option Giant',
  'Option Giant Pro',
  'Option League',
  'Option Next',
  'Option Peer',
  'Option Rally',
  'Option Stars Global',
  'Option Vic',
  'Option XE',
  'Option500',
  'OptionBit Pro',
  'OptionFair Pro',
  'OptionRally',
  'Options Banc',
  'Options Click',
  'Options Domination',
  'Options Expires',
  'Options Hunter',
  'Options Maker',
  'Options Matrix',
  'Options Multiplier',
  'Options Navigator',
  'Options Prime',
  'Options Rider',
  'Options Robot',
  'Options XO',
  'Pearl Options',
  'Pip365',
  'Platinum Trader',
  'Positif Profits',
  'Premier Option',
  'Profit Genius',
  'Profit Magnet',
  'Quick Cash System',
  'Quick Option',
  'Random Logic',
  'Real Binary Bot',
  'Real Profits',
  'Redwood Options Pro',
  'RBOption',
  'RICH VIP CLUB',
  'Royal Binary',
  'Safe Trader',
  'Scam Binary',
  'Silver Options',
  'Simple Binary',
  'Sky Binary',
  'SnapCash Binary',
  'Stern Options',
  'Stock Trading',
  'Super Binary',
  'Swap Master',
  'The Binary System',
  'The Dubai Formula',
  'The Independent Profit',
  'The Lazy Day Trader',
  'The Samaritan System',
  'The Tesler App',
  'Titan Trade',
  'Top Binary Options',
  'Traderush Pro',
  'Tradorax',
  'Trend Xpert',
  'Triumph Options',
  'True Binary',
  'Trustworthy Binary',
  'UBinary Pro',
  'Ultra Binary',
  'Unicorn Binary',
  'United Trading',
  'Up Down Signals',
  'Vertor Markets',
  'Viral Binary',
  'VirtNext',
  'Windsor Brokers',
  'X Trade',
  'Ybinary',
  'Zulutrade Binary',
  'Binary Uno',
  'Binary Capital',
  'Boss Binary',
  'Binary VIP',
  'Binary Ace',
  'Binary Alpha',
  'Binary Apex',
  'Binary Arena',
  'Binary Base',
  'Binary Blade',
  'Binary Boost',
  'Binary Bull',
  'Binary Core',
  'Binary Crown',
  'Binary Dash',
  'Binary Delta',
  'Binary Edge',
  'Binary Elite',
  'Binary Express',
  'Binary Fast',
  'Binary Fire',
  'Binary Flash',
  'Binary Force',
  'Binary Fusion',
  'Binary Gold',
  'Binary Hive',
  'Binary Hub',
  'Binary IQ',
  'Binary King',
  'Binary Knight',
  'Binary Labs',
  'Binary Link',
  'Binary Logic',
  'Binary Master',
  'Binary Max',
  'Binary Matrix',
  'Binary Net',
  'Binary Nova',
  'Binary Omega',
  'Binary One',
  'Binary Pay',
  'Binary Peak',
  'Binary Pro Max',
  'Binary Prime',
  'Binary Pulse',
  'Binary Quest',
  'Binary Rank',
  'Binary Rush',
  'Binary Shield',
  'Binary Signal',
  'Binary Star',
  'Binary Storm',
  'Binary Swift',
  'Binary Titan',
  'Binary Trade Hub',
  'Binary Ultra',
  'Binary Vault',
  'Binary Wave',
  'Binary Web',
  'Binary X',
  'Binary Yard',
  'Binary Zen',
  'Binary Zone',
];
const timeframes = ['1m', '2m', '5m', '10m', '15m', '30m', '1h'];
const strategies = [
  { value: 'Scalping', icon: <Zap size={14} />, desc: 'Fast trades' },
  { value: 'Trend', icon: <TrendingUp size={14} />, desc: 'Follow trends' },
  { value: 'Reversal', icon: <Activity size={14} />, desc: 'Catch reversals' },
];

const categoryConfig: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  all: { label: 'All', icon: <Globe size={14} />, color: '#00d4ff' },
  forex: { label: 'Forex', icon: <TrendingUpIcon size={14} />, color: '#22c55e' },
  crypto: { label: 'Crypto', icon: <Coins size={14} />, color: '#f7931a' },
  otc: { label: 'OTC', icon: <BarChart3 size={14} />, color: '#a855f7' },
  commodity: { label: 'Commodity', icon: <Gem size={14} />, color: '#eab308' },
  index: { label: 'Index', icon: <Landmark size={14} />, color: '#ec4899' },
};

// Fallback pairs in case API fails
const fallbackPairs: PairData[] = [
  { id: 'f1', symbol: 'EUR/USD', name: 'Euro / US Dollar', category: 'forex', basePrice: 1.0856, pipSize: 0.0001 },
  { id: 'f2', symbol: 'GBP/USD', name: 'British Pound / US Dollar', category: 'forex', basePrice: 1.272, pipSize: 0.0001 },
  { id: 'f3', symbol: 'USD/JPY', name: 'US Dollar / Japanese Yen', category: 'forex', basePrice: 151.85, pipSize: 0.01 },
  { id: 'f4', symbol: 'AUD/USD', name: 'Australian Dollar / US Dollar', category: 'forex', basePrice: 0.658, pipSize: 0.0001 },
  { id: 'f5', symbol: 'USD/CAD', name: 'US Dollar / Canadian Dollar', category: 'forex', basePrice: 1.362, pipSize: 0.0001 },
  { id: 'f6', symbol: 'USD/CHF', name: 'US Dollar / Swiss Franc', category: 'forex', basePrice: 0.8845, pipSize: 0.0001 },
  { id: 'f7', symbol: 'NZD/USD', name: 'NZ Dollar / US Dollar', category: 'forex', basePrice: 0.612, pipSize: 0.0001 },
  { id: 'f8', symbol: 'EUR/GBP', name: 'Euro / British Pound', category: 'forex', basePrice: 0.853, pipSize: 0.0001 },
  { id: 'f9', symbol: 'GBP/JPY', name: 'British Pound / Japanese Yen', category: 'forex', basePrice: 193.2, pipSize: 0.01 },
  { id: 'f10', symbol: 'EUR/JPY', name: 'Euro / Japanese Yen', category: 'forex', basePrice: 164.85, pipSize: 0.01 },
  { id: 'f11', symbol: 'BTC/USD', name: 'Bitcoin / US Dollar', category: 'crypto', basePrice: 67250, pipSize: 0.01 },
  { id: 'f12', symbol: 'ETH/USD', name: 'Ethereum / US Dollar', category: 'crypto', basePrice: 3520, pipSize: 0.01 },
  { id: 'f13', symbol: 'SOL/USD', name: 'Solana / US Dollar', category: 'crypto', basePrice: 148.5, pipSize: 0.01 },
  { id: 'f14', symbol: 'BNB/USD', name: 'Binance Coin / US Dollar', category: 'crypto', basePrice: 585, pipSize: 0.01 },
  { id: 'f15', symbol: 'XRP/USD', name: 'Ripple / US Dollar', category: 'crypto', basePrice: 0.625, pipSize: 0.0001 },
  { id: 'f16', symbol: 'DOGE/USD', name: 'Dogecoin / US Dollar', category: 'crypto', basePrice: 0.1645, pipSize: 0.0001 },
  { id: 'f17', symbol: 'ADA/USD', name: 'Cardano / US Dollar', category: 'crypto', basePrice: 0.645, pipSize: 0.0001 },
  { id: 'f18', symbol: 'DOT/USD', name: 'Polkadot / US Dollar', category: 'crypto', basePrice: 7.25, pipSize: 0.01 },
  { id: 'f19', symbol: 'LINK/USD', name: 'Chainlink / US Dollar', category: 'crypto', basePrice: 15.8, pipSize: 0.01 },
  { id: 'f20', symbol: 'AVAX/USD', name: 'Avalanche / US Dollar', category: 'crypto', basePrice: 35.8, pipSize: 0.01 },
  { id: 'f21', symbol: 'XAU/USD', name: 'Gold / US Dollar', category: 'commodity', basePrice: 2345.5, pipSize: 0.01 },
  { id: 'f22', symbol: 'XAG/USD', name: 'Silver / US Dollar', category: 'commodity', basePrice: 28.5, pipSize: 0.01 },
  { id: 'f23', symbol: 'WTI/USD', name: 'West Texas Oil / US Dollar', category: 'commodity', basePrice: 78.5, pipSize: 0.01 },
  { id: 'f24', symbol: 'BRENT/USD', name: 'Brent Oil / US Dollar', category: 'commodity', basePrice: 82.3, pipSize: 0.01 },
  { id: 'f25', symbol: 'EUR/USD OTC', name: 'Euro / USD OTC', category: 'otc', basePrice: 1.0856, pipSize: 0.0001 },
  { id: 'f26', symbol: 'GBP/USD OTC', name: 'British Pound / USD OTC', category: 'otc', basePrice: 1.272, pipSize: 0.0001 },
  { id: 'f27', symbol: 'USD/JPY OTC', name: 'US Dollar / JPY OTC', category: 'otc', basePrice: 151.85, pipSize: 0.01 },
  { id: 'f28', symbol: 'USD/CAD OTC', name: 'US Dollar / CAD OTC', category: 'otc', basePrice: 1.362, pipSize: 0.0001 },
  { id: 'f29', symbol: 'AUD/USD OTC', name: 'Australian Dollar / USD OTC', category: 'otc', basePrice: 0.658, pipSize: 0.0001 },
  { id: 'f30', symbol: 'USD/BRL OTC', name: 'US Dollar / BRL OTC', category: 'otc', basePrice: 5.15, pipSize: 0.01 },
  { id: 'f31', symbol: 'NAS100/USD', name: 'NASDAQ 100 / US Dollar', category: 'index', basePrice: 18520, pipSize: 0.01 },
  { id: 'f32', symbol: 'US500/USD', name: 'S&P 500 / US Dollar', category: 'index', basePrice: 5285.5, pipSize: 0.01 },
  { id: 'f33', symbol: 'US30/USD', name: 'Dow Jones 30 / US Dollar', category: 'index', basePrice: 39875, pipSize: 0.01 },
];

function ConfigurationPanel() {
  const {
    selectedBroker, setSelectedBroker,
    selectedPair, setSelectedPair,
    selectedTimeframe, setSelectedTimeframe,
    selectedStrategy, setSelectedStrategy,
    pairs, setPairs,
    selectedPairCategory, setSelectedPairCategory,
  } = useAppStore();

  const [pairsLoaded, setPairsLoaded] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isBrokerOpen, setIsBrokerOpen] = useState(false);
  const [brokerSearch, setBrokerSearch] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const brokerRef = useRef<HTMLDivElement>(null);

  // Fetch pairs from API, fallback to inline data
  useEffect(() => {
    async function fetchPairs() {
      try {
        const res = await fetch('/api/pairs');
        if (res.ok) {
          const data = await res.json();
          if (data.pairs && data.pairs.length > 0) {
            setPairs(data.pairs);
            setPairsLoaded(true);
            return;
          }
        }
      } catch (e) {
        // API failed, use fallback
      }
      // Fallback to inline pairs
      setPairs(fallbackPairs);
      setPairsLoaded(true);
    }
    fetchPairs();
  }, [setPairs]);

  const allPairs = pairs.length > 0 ? pairs : fallbackPairs;

  const filteredPairs = useMemo(() => {
    if (selectedPairCategory === 'all') return allPairs;
    return allPairs.filter((p) => p.category === selectedPairCategory);
  }, [allPairs, selectedPairCategory]);

  const filteredBrokers = useMemo(() => {
    if (!brokerSearch.trim()) return brokers;
    const q = brokerSearch.toLowerCase();
    return brokers.filter((b) => b.toLowerCase().includes(q));
  }, [brokerSearch]);

  // Auto-switch pair when category changes and current pair isn't in new category
  useEffect(() => {
    if (selectedPairCategory !== 'all') {
      const pairInCategory = allPairs.find((p) => p.symbol === selectedPair && p.category === selectedPairCategory);
      if (!pairInCategory && filteredPairs.length > 0) {
        setSelectedPair(filteredPairs[0].symbol);
      }
    }
  }, [selectedPairCategory, allPairs, filteredPairs, selectedPair, setSelectedPair]);

  const selectedPairData = allPairs.find((p) => p.symbol === selectedPair);

  const categories = ['all', 'forex', 'crypto', 'otc', 'commodity', 'index'];

  // Close pair dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    if (isDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isDropdownOpen]);

  // Close broker dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (brokerRef.current && !brokerRef.current.contains(e.target as Node)) {
        setIsBrokerOpen(false);
        setBrokerSearch('');
      }
    }
    if (isBrokerOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isBrokerOpen]);

  return (
    <div className="space-y-3">
      {/* Row 1: Broker + Timeframe + Strategy in one compact row */}
      <div className="glass-card rounded-xl p-3 sm:p-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Broker - Custom Dropdown */}
          <div className="space-y-1">
            <label className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider">Broker</label>
            <div ref={brokerRef} className="relative">
              <button
                type="button"
                onClick={() => { setIsBrokerOpen(!isBrokerOpen); setBrokerSearch(''); }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg border border-[#1a2744]/80 transition-all duration-200 cursor-pointer hover:border-[#00d4ff]/30 focus:outline-none focus:border-[#00d4ff]/50"
                style={{ background: 'rgba(17, 29, 53, 0.8)' }}
              >
                <span className="flex-1 text-left text-xs font-medium text-foreground truncate">{selectedBroker}</span>
                <ChevronDown size={14} className={`text-muted-foreground shrink-0 transition-transform duration-200 ${isBrokerOpen ? 'rotate-180' : ''}`} />
              </button>

              {isBrokerOpen && (
                <div className="absolute z-50 mt-1 w-full max-h-[280px] overflow-hidden rounded-lg border border-[#1a2744] shadow-2xl shadow-black/50 flex flex-col" style={{ background: '#0d1b35' }}>
                  <div className="p-2 border-b border-[#1a2744]">
                    <input
                      type="text"
                      value={brokerSearch}
                      onChange={(e) => setBrokerSearch(e.target.value)}
                      placeholder="Search broker..."
                      className="w-full px-2 py-1.5 rounded-md text-xs bg-[#111d35] border border-[#1a2744] text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-[#00d4ff]/50"
                      autoFocus
                    />
                  </div>
                  <div className="overflow-y-auto flex-1">
                    {filteredBrokers.length === 0 ? (
                      <div className="py-6 text-center text-xs text-muted-foreground">No broker found</div>
                    ) : (
                      <div className="py-0.5">
                        {filteredBrokers.map((b) => {
                          const isSel = b === selectedBroker;
                          return (
                            <button
                              key={b}
                              onClick={() => { setSelectedBroker(b); setIsBrokerOpen(false); setBrokerSearch(''); }}
                              className={`w-full flex items-center gap-2 px-3 py-2 text-left transition-all duration-150 ${
                                isSel ? '' : 'hover:bg-white/5'
                              }`}
                              style={isSel ? { background: 'rgba(0, 212, 255, 0.1)' } : {}}
                            >
                              <span className="text-xs font-bold truncate" style={{ color: isSel ? '#00d4ff' : '#e2e8f0' }}>{b}</span>
                              {isSel && <Check size={12} className="shrink-0 text-[#00d4ff]" />}
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Timeframe */}
          <div className="space-y-1">
            <label className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider">Timeframe</label>
            <div className="flex gap-1">
              {timeframes.map((tf) => (
                <button
                  key={tf}
                  onClick={() => setSelectedTimeframe(tf)}
                  className={`flex-1 py-2 rounded-lg text-[10px] font-bold transition-all duration-200 ${
                    selectedTimeframe === tf
                      ? 'bg-gradient-to-r from-[#00d4ff] to-[#a855f7] text-white shadow-[0_0_8px_rgba(0,212,255,0.3)]'
                      : 'glass-input text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
          {/* Strategy */}
          <div className="space-y-1">
            <label className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider">Strategy</label>
            <div className="flex gap-1">
              {strategies.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setSelectedStrategy(s.value)}
                  className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-lg text-[10px] font-bold transition-all duration-200 ${
                    selectedStrategy === s.value
                      ? 'bg-gradient-to-r from-[#00d4ff] to-[#a855f7] text-white shadow-[0_0_8px_rgba(0,212,255,0.3)]'
                      : 'glass-input text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {s.icon}
                  <span className="hidden sm:inline text-[10px]">{s.value}</span>
                </button>
              ))}
            </div>
          </div>
          {/* Strategy */}
          <div className="space-y-1">
            <label className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider">Strategy</label>
            <div className="flex gap-1">
              {strategies.map((s) => (
                <button
                  key={s.value}
                  onClick={() => setSelectedStrategy(s.value)}
                  className={`flex-1 flex items-center justify-center gap-1 py-2 rounded-lg text-[10px] font-bold transition-all duration-200 ${
                    selectedStrategy === s.value
                      ? 'bg-gradient-to-r from-[#00d4ff] to-[#a855f7] text-white shadow-[0_0_8px_rgba(0,212,255,0.3)]'
                      : 'glass-input text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {s.icon}
                  <span className="hidden sm:inline text-[10px]">{s.value}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-[#1a2744]/60" />

        {/* Trade Pair Section */}
        <div className="space-y-2">
          <label className="text-[9px] text-muted-foreground font-semibold uppercase tracking-wider">Trade Pair</label>
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5" style={{ scrollbarWidth: 'none' }}>
            {categories.map((cat) => {
              const cfg = categoryConfig[cat];
              const isActive = selectedPairCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedPairCategory(cat)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] sm:text-xs font-bold transition-all duration-200 whitespace-nowrap border ${
                    isActive
                      ? 'border-transparent'
                      : 'border-[#1a2744]/60 text-muted-foreground hover:text-foreground'
                  }`}
                  style={isActive ? {
                    background: `${cfg.color}15`,
                    color: cfg.color,
                    borderColor: `${cfg.color}40`,
                  } : {}}
                >
                  {cfg.icon}
                  {cfg.label}
                </button>
              );
            })}
          </div>

          {/* Pair Selector Dropdown */}
          <div ref={dropdownRef} className="relative">
            <button
              type="button"
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border border-[#1a2744]/80 transition-all duration-200 cursor-pointer hover:border-[#00d4ff]/30 focus:outline-none focus:border-[#00d4ff]/50"
              style={{ background: `${categoryConfig[selectedPairData?.category || 'forex']?.color || '#00d4ff'}06` }}
            >
              {selectedPairData && (
                <>
                  <span className="w-7 h-7 rounded-md flex items-center justify-center shrink-0" style={{ background: `${categoryConfig[selectedPairData.category]?.color || '#00d4ff'}15`, color: categoryConfig[selectedPairData.category]?.color || '#00d4ff' }}>
                    {categoryConfig[selectedPairData.category]?.icon || <Globe size={14} />}
                  </span>
                  <div className="flex-1 min-w-0 text-left">
                    <span className="text-sm font-bold text-foreground">{selectedPairData.symbol}</span>
                    <span className="text-[10px] text-muted-foreground ml-2 hidden sm:inline">{selectedPairData.name}</span>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs font-mono font-bold text-foreground">{selectedPairData.basePrice >= 1000 ? selectedPairData.basePrice.toLocaleString('en-US', { maximumFractionDigits: 2 }) : selectedPairData.basePrice}</span>
                  </div>
                </>
              )}
              <ChevronDown size={14} className={`text-muted-foreground shrink-0 transition-transform duration-200 ${isDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Dropdown List */}
            {isDropdownOpen && (
              <div className="absolute z-50 mt-1 w-full max-h-[260px] overflow-y-auto rounded-lg border border-[#1a2744] shadow-2xl shadow-black/50" style={{ background: '#0d1b35' }}>
                {filteredPairs.length === 0 ? (
                  <div className="py-6 text-center text-xs text-muted-foreground">No pairs found</div>
                ) : (
                  <div className="py-1">
                    {filteredPairs.map((p) => {
                      const isSel = p.symbol === selectedPair;
                      const cfg = categoryConfig[p.category];
                      return (
                        <button
                          key={p.id}
                          onClick={() => { setSelectedPair(p.symbol); setIsDropdownOpen(false); }}
                          className={`w-full flex items-center gap-2 px-3 py-2 text-left transition-all duration-150 ${
                            isSel ? '' : 'hover:bg-white/5'
                          }`}
                          style={isSel ? { background: `${cfg?.color || '#00d4ff'}10` } : {}}
                        >
                          <span className="text-xs font-bold" style={{ color: isSel ? (cfg?.color || '#00d4ff') : '#e2e8f0' }}>{p.symbol}</span>
                          <span className="text-[10px] text-muted-foreground hidden sm:inline truncate">{p.name}</span>
                          <span className="text-[10px] font-mono text-muted-foreground ml-auto shrink-0">{p.basePrice >= 1000 ? p.basePrice.toLocaleString('en-US', { maximumFractionDigits: 2 }) : p.basePrice}</span>
                          {isSel && <Check size={12} className="shrink-0" style={{ color: cfg?.color || '#00d4ff' }} />}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-[#1a2744]/60" />

        {/* Get Signal Button */}
        <GetSignalButton />
      </div>
    </div>
  );
}

// ==================== SIGNAL OUTPUT ====================
function SignalOutput() {
  const { currentSignal, isGenerating } = useAppStore();

  if (isGenerating) {
    return (
      <div className="glass-card rounded-2xl p-8 sm:p-12 flex flex-col items-center justify-center gap-4">
        <div className="relative w-20 h-20">
          <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-[#00d4ff] border-r-[#a855f7] spinner-glow" />
          <div className="absolute inset-2 rounded-full border-2 border-transparent border-b-[#00d4ff] border-l-[#a855f7]" style={{ animation: 'spin-glow 1s linear infinite reverse' }} />
          <div className="absolute inset-4 rounded-full border-2 border-transparent border-t-[#22c55e]" style={{ animation: 'spin-glow 0.7s linear infinite' }} />
          <div className="absolute inset-0 flex items-center justify-center">
            <Activity size={24} className="text-[#00d4ff]" />
          </div>
        </div>
        <div className="text-center space-y-2">
          <p className="text-sm font-semibold text-[#00d4ff] glow-text-blue">ANALYZING MARKET</p>
          <p className="text-xs text-muted-foreground">Calculating RSI, MACD, Moving Averages & more...</p>
        </div>
        <div className="flex gap-2 mt-2">
          {[0, 1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="w-2 h-2 rounded-full bg-[#00d4ff]"
              style={{ animation: `pulse 1.5s ease-in-out ${i * 0.2}s infinite` }}
            />
          ))}
        </div>
      </div>
    );
  }

  if (!currentSignal) {
    return (
      <div className="glass-card rounded-2xl p-8 sm:p-12 flex flex-col items-center justify-center gap-4">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#00d4ff]/10 to-[#a855f7]/10 flex items-center justify-center border border-[#1a2744]">
          <Target size={32} className="text-muted-foreground" />
        </div>
        <div className="text-center space-y-2">
          <p className="text-sm font-semibold text-foreground">Ready to Analyze</p>
          <p className="text-xs text-muted-foreground max-w-sm">
            Configure your trading parameters above and click &quot;Get Signal&quot; to receive AI-powered trading signals with technical analysis.
          </p>
        </div>
      </div>
    );
  }

  const signal = currentSignal;
  const isBuy = signal.direction === 'BUY';

  return (
    <div className="signal-appear">
      <div className={`glass-card rounded-2xl p-4 sm:p-6 relative overflow-hidden ${
        isBuy ? 'glow-green' : 'glow-red'
      }`}>
        {/* Background gradient */}
        <div className={`absolute inset-0 opacity-5 ${
          isBuy ? 'bg-gradient-to-br from-[#22c55e] to-transparent' : 'bg-gradient-to-br from-[#ef4444] to-transparent'
        }`} />

        <div className="relative z-10 space-y-4">
          {/* Direction Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
                isBuy
                  ? 'bg-[#22c55e]/20 border border-[#22c55e]/40'
                  : 'bg-[#ef4444]/20 border border-[#ef4444]/40'
              }`}>
                {isBuy ? (
                  <TrendingUp size={28} className="text-[#22c55e]" />
                ) : (
                  <TrendingDown size={28} className="text-[#ef4444]" />
                )}
              </div>
              <div>
                <div className={`text-3xl sm:text-4xl font-extrabold tracking-tight ${
                  isBuy ? 'text-[#22c55e]' : 'text-[#ef4444]'
                }`}>
                  {signal.direction}
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  {signal.pair} · {signal.broker} · {signal.timeframe}
                </div>
              </div>
            </div>

            <div className="text-right">
              <div className={`text-2xl sm:text-3xl font-bold ${
                signal.accuracy >= 80 ? 'text-[#22c55e]' : signal.accuracy >= 70 ? 'text-[#eab308]' : 'text-[#ef4444]'
              }`}>
                {signal.accuracy}%
              </div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-widest">Accuracy</div>
            </div>
          </div>

          {/* Info Bar */}
          <div className="grid grid-cols-3 gap-3">
            <div className="glass-input rounded-xl p-3 text-center">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Entry Price</div>
              <div className="text-sm font-bold font-mono text-foreground">{signal.entryPrice}</div>
            </div>
            <div className={`rounded-xl p-3 text-center ${
              signal.riskLevel === 'Low' ? 'risk-low' : signal.riskLevel === 'Medium' ? 'risk-medium' : 'risk-high'
            }`}>
              <div className="text-[10px] uppercase tracking-wider mb-1 opacity-80">Risk Level</div>
              <div className="text-sm font-bold">{signal.riskLevel}</div>
            </div>
            <div className="glass-input rounded-xl p-3 text-center">
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Strategy</div>
              <div className="text-sm font-bold text-[#a855f7]">{signal.strategy}</div>
            </div>
          </div>

          {/* Accuracy Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Confidence Level</span>
              <span className={`font-bold ${signal.accuracy >= 80 ? 'text-[#22c55e]' : signal.accuracy >= 70 ? 'text-[#eab308]' : 'text-[#ef4444]'}`}>
                {signal.accuracy}%
              </span>
            </div>
            <div className="indicator-bar">
              <div
                className={`indicator-bar-fill transition-all duration-1000 ease-out ${
                  signal.accuracy >= 80 ? 'bg-gradient-to-r from-[#22c55e] to-[#22c55e]/70' :
                  signal.accuracy >= 70 ? 'bg-gradient-to-r from-[#eab308] to-[#eab308]/70' :
                  'bg-gradient-to-r from-[#ef4444] to-[#ef4444]/70'
                }`}
                style={{ width: `${signal.accuracy}%` }}
              />
            </div>
          </div>

          {/* Technical Indicators */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#00d4ff] uppercase tracking-wider">
              <Gauge size={14} />
              Technical Indicators
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* RSI */}
              <div className="glass-input rounded-xl p-3">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-foreground">RSI (14)</span>
                  <span className="text-xs font-mono font-bold text-[#00d4ff]">{signal.indicators.rsi.value}</span>
                </div>
                <div className="text-[10px] text-muted-foreground">{signal.indicators.rsi.signal}</div>
                <div className="indicator-bar mt-2">
                  <div
                    className="indicator-bar-fill bg-gradient-to-r from-[#ef4444] via-[#eab308] to-[#22c55e]"
                    style={{ width: `${Math.min(100, signal.indicators.rsi.value)}%` }}
                  />
                </div>
              </div>

              {/* MACD */}
              <div className="glass-input rounded-xl p-3">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-foreground">MACD</span>
                  <span className={`text-xs font-mono font-bold ${signal.indicators.macd.histogram > 0 ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
                    {signal.indicators.macd.histogram > 0 ? '+' : ''}{signal.indicators.macd.histogram.toFixed(6)}
                  </span>
                </div>
                <div className="text-[10px] text-muted-foreground">{signal.indicators.macd.signal}</div>
                <div className="indicator-bar mt-2">
                  <div
                    className={`indicator-bar-fill ${signal.indicators.macd.histogram > 0 ? 'bg-[#22c55e]' : 'bg-[#ef4444]'}`}
                    style={{ width: `${Math.min(100, Math.abs(signal.indicators.macd.histogram) * 10000 + 20)}%` }}
                  />
                </div>
              </div>

              {/* Moving Averages */}
              <div className="glass-input rounded-xl p-3">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-foreground">Moving Avg</span>
                  <span className={`text-xs font-mono font-bold ${signal.indicators.ma.signal.includes('Bullish') ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
                    {signal.indicators.ma.signal.includes('Bullish') ? '↑' : '↓'}
                  </span>
                </div>
                <div className="flex gap-4 text-[10px]">
                  <span className="text-muted-foreground">MA20: <span className="text-foreground font-mono">{signal.indicators.ma.value20}</span></span>
                  <span className="text-muted-foreground">MA50: <span className="text-foreground font-mono">{signal.indicators.ma.value50}</span></span>
                </div>
                <div className="text-[10px] text-muted-foreground mt-1">{signal.indicators.ma.signal}</div>
              </div>

              {/* Stochastic */}
              <div className="glass-input rounded-xl p-3">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-foreground">Stochastic</span>
                  <span className="text-xs font-mono font-bold text-[#a855f7]">
                    {signal.indicators.stochastic.k}/{signal.indicators.stochastic.d}
                  </span>
                </div>
                <div className="text-[10px] text-muted-foreground">{signal.indicators.stochastic.signal}</div>
                <div className="indicator-bar mt-2">
                  <div
                    className="indicator-bar-fill bg-gradient-to-r from-[#a855f7] to-[#ec4899]"
                    style={{ width: `${signal.indicators.stochastic.k}%` }}
                  />
                </div>
              </div>

              {/* Bollinger Bands */}
              <div className="glass-input rounded-xl p-3 sm:col-span-2">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-foreground">Bollinger Bands</span>
                  <span className="text-xs font-mono font-bold text-[#eab308]">Position: {signal.indicators.bollinger.position}</span>
                </div>
                <div className="flex gap-6 text-[10px]">
                  <span className="text-muted-foreground">Upper: <span className="text-[#22c55e] font-mono">{signal.indicators.bollinger.upper}</span></span>
                  <span className="text-muted-foreground">Mid: <span className="text-[#eab308] font-mono">{signal.indicators.bollinger.middle}</span></span>
                  <span className="text-muted-foreground">Lower: <span className="text-[#ef4444] font-mono">{signal.indicators.bollinger.lower}</span></span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ==================== GET SIGNAL BUTTON ====================
function GetSignalButton() {
  const {
    isGenerating, setIsGenerating, setCurrentSignal,
    selectedBroker, selectedPair, selectedTimeframe, selectedStrategy,
    soundEnabled, token, user, setSignalHistory, setHistoryStats,
  } = useAppStore();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);

  const fetchHistory = useCallback(async () => {
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      const res = await fetch('/api/signals/history', { headers });
      if (res.ok) {
        const data = await res.json();
        setSignalHistory(data.signals);
        setHistoryStats(data.stats);
      }
    } catch (e) {
      console.log('History fetch error');
    }
  }, [token, setSignalHistory, setHistoryStats]);

  const generateSignal = useCallback(async () => {
    if (isGenerating) return;
    setIsGenerating(true);
    setCountdown(3);

    for (let i = 3; i > 0; i--) {
      setCountdown(i);
      await new Promise((r) => setTimeout(r, 1000));
    }

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch('/api/signals/generate', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          broker: selectedBroker,
          pair: selectedPair,
          timeframe: selectedTimeframe,
          strategy: selectedStrategy,
        }),
      });

      if (res.ok) {
        const signal: TradingSignal = await res.json();
        setCurrentSignal(signal);

        if (soundEnabled) {
          playSignalSound(signal.direction);
        }

        fetchHistory();
      }
    } catch (e) {
      console.error('Signal generation error:', e);
    } finally {
      setIsGenerating(false);
      setCountdown(null);
    }
  }, [isGenerating, setIsGenerating, setCurrentSignal, selectedBroker, selectedPair, selectedTimeframe, selectedStrategy, soundEnabled, token, fetchHistory]);

  return (
    <button
      onClick={generateSignal}
      disabled={isGenerating}
      className={`w-full neon-button rounded-xl py-2.5 text-xs font-bold flex items-center justify-center gap-2 transition-all duration-300 ${
        isGenerating ? 'opacity-80 cursor-not-allowed' : ''
      }`}
    >
      {isGenerating ? (
        <>
          <RefreshCw size={14} className="animate-spin" />
          <span>Analyzing... {countdown}s</span>
        </>
      ) : (
        <>
          <Zap size={14} />
          <span>Get Signal</span>
        </>
      )}
    </button>
  );
}

// ==================== SIGNALS VIEW ====================
function SignalsView() {
  return (
    <div className="space-y-4 sm:space-y-6">
      <ConfigurationPanel />
      <SignalOutput />

      {/* Disclaimer */}
      <div className="glass-card rounded-xl p-3 sm:p-4">
        <div className="flex items-start gap-2">
          <Shield size={14} className="text-[#eab308] mt-0.5 shrink-0" />
          <p className="text-[10px] sm:text-xs text-muted-foreground leading-relaxed">
            <span className="text-[#eab308] font-semibold">Signal Only Bot:</span> This bot does NOT execute any trades. It only reads live market data (Binance, Forex APIs) and generates BUY/SELL signals based on real technical analysis (RSI, MACD, Bollinger, Stochastic). Trading involves significant risk. Always do your own research.
          </p>
        </div>
      </div>
    </div>
  );
}

// ==================== DASHBOARD VIEW ====================
function DashboardView() {
  const { user, historyStats } = useAppStore();

  const stats = [
    { label: 'Total Trades', value: user?.totalTrades || historyStats.total, icon: <BarChart3 size={20} />, color: '#00d4ff' },
    { label: 'Win Rate', value: `${user?.winRate || historyStats.winRate}%`, icon: <Target size={20} />, color: '#22c55e' },
    { label: 'Total Profit', value: `$${(user?.profit || historyStats.totalProfit).toFixed(2)}`, icon: <DollarSign size={20} />, color: '#a855f7' },
    { label: 'Best Streak', value: '7W', icon: <Trophy size={20} />, color: '#eab308' },
  ];

  const recentActivity = [
    { pair: 'BTC/USD', direction: 'BUY', result: 'WIN', profit: '+$5.42', time: '2 min ago' },
    { pair: 'EUR/USD', direction: 'SELL', result: 'WIN', profit: '+$3.21', time: '5 min ago' },
    { pair: 'USD/BRL OTC', direction: 'BUY', result: 'LOSS', profit: '-$1.85', time: '8 min ago' },
    { pair: 'GBP/USD', direction: 'SELL', result: 'WIN', profit: '+$4.10', time: '12 min ago' },
    { pair: 'XAU/USD', direction: 'BUY', result: 'WIN', profit: '+$7.33', time: '15 min ago' },
  ];

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg sm:text-xl font-bold text-foreground">Dashboard</h2>
        {user && (
          <span className={`text-[10px] sm:text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider ${
            user.plan === 'vip' ? 'bg-[#a855f7]/20 text-[#a855f7] border border-[#a855f7]/30' :
            user.plan === 'pro' ? 'bg-[#00d4ff]/20 text-[#00d4ff] border border-[#00d4ff]/30' :
            'bg-muted text-muted-foreground border border-border'
          }`}>
            {user.plan} Plan
          </span>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-card rounded-2xl p-4 sm:p-5"
          >
            <div className="flex items-center gap-2 mb-3">
              <div className="p-2 rounded-xl" style={{ background: `${stat.color}15`, color: stat.color }}>
                {stat.icon}
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-bold text-foreground">{stat.value}</div>
            <div className="text-[10px] sm:text-xs text-muted-foreground mt-1 uppercase tracking-wider">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Performance Chart */}
      <div className="glass-card rounded-2xl p-4 sm:p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-foreground">Performance Overview</h3>
          <div className="flex gap-4 text-[10px] sm:text-xs">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-[#22c55e]" />
              <span className="text-muted-foreground">Wins ({historyStats.wins})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-[#ef4444]" />
              <span className="text-muted-foreground">Losses ({historyStats.losses})</span>
            </div>
          </div>
        </div>

        {/* Visual Bar Chart */}
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground w-12">Win %</span>
            <div className="flex-1 indicator-bar h-6 rounded-lg">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${historyStats.winRate}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
                className="h-full rounded-lg bg-gradient-to-r from-[#22c55e] to-[#22c55e]/60"
              />
            </div>
            <span className="text-xs font-bold text-[#22c55e] w-12 text-right">{historyStats.winRate}%</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground w-12">Loss %</span>
            <div className="flex-1 indicator-bar h-6 rounded-lg">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${100 - historyStats.winRate}%` }}
                transition={{ duration: 1, ease: 'easeOut', delay: 0.2 }}
                className="h-full rounded-lg bg-gradient-to-r from-[#ef4444] to-[#ef4444]/60"
              />
            </div>
            <span className="text-xs font-bold text-[#ef4444] w-12 text-right">{(100 - historyStats.winRate).toFixed(0)}%</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground w-12">Accuracy</span>
            <div className="flex-1 indicator-bar h-6 rounded-lg">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${historyStats.avgAccuracy}%` }}
                transition={{ duration: 1, ease: 'easeOut', delay: 0.4 }}
                className="h-full rounded-lg bg-gradient-to-r from-[#00d4ff] to-[#a855f7]"
              />
            </div>
            <span className="text-xs font-bold text-[#00d4ff] w-12 text-right">{historyStats.avgAccuracy}%</span>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="glass-card rounded-2xl p-4 sm:p-6">
        <h3 className="text-sm font-semibold text-foreground mb-4">Recent Activity</h3>
        <div className="space-y-2">
          {recentActivity.map((activity, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center justify-between p-3 rounded-xl glass-input hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                  activity.direction === 'BUY' ? 'bg-[#22c55e]/20 text-[#22c55e]' : 'bg-[#ef4444]/20 text-[#ef4444]'
                }`}>
                  {activity.direction === 'BUY' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">{activity.pair}</div>
                  <div className="text-[10px] text-muted-foreground">{activity.time}</div>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-sm font-bold ${
                  activity.result === 'WIN' ? 'text-[#22c55e]' : 'text-[#ef4444]'
                }`}>
                  {activity.profit}
                </div>
                <div className={`text-[10px] font-semibold ${
                  activity.result === 'WIN' ? 'text-[#22c55e]/70' : 'text-[#ef4444]/70'
                }`}>
                  {activity.result}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ==================== HISTORY VIEW ====================
function HistoryView() {
  const { signalHistory, historyStats } = useAppStore();

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg sm:text-xl font-bold text-foreground">Signal History</h2>
        <div className="flex gap-2 text-xs">
          <div className="glass-input rounded-lg px-3 py-1.5 text-[#22c55e] font-bold">
            W: {historyStats.wins}
          </div>
          <div className="glass-input rounded-lg px-3 py-1.5 text-[#ef4444] font-bold">
            L: {historyStats.losses}
          </div>
          <div className="glass-input rounded-lg px-3 py-1.5 text-[#00d4ff] font-bold">
            Rate: {historyStats.winRate}%
          </div>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass-card rounded-xl p-3 text-center">
          <div className="text-lg sm:text-xl font-bold text-foreground">{historyStats.total}</div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Total Signals</div>
        </div>
        <div className="glass-card rounded-xl p-3 text-center">
          <div className={`text-lg sm:text-xl font-bold ${historyStats.totalProfit >= 0 ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
            ${historyStats.totalProfit.toFixed(2)}
          </div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Total P/L</div>
        </div>
        <div className="glass-card rounded-xl p-3 text-center">
          <div className="text-lg sm:text-xl font-bold text-[#00d4ff]">{historyStats.avgAccuracy}%</div>
          <div className="text-[10px] text-muted-foreground uppercase tracking-wider">Avg Accuracy</div>
        </div>
      </div>

      {/* History List */}
      <div className="glass-card rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-[#1a2744]">
                <th className="text-left p-3 text-muted-foreground font-medium uppercase tracking-wider text-[10px]">Pair</th>
                <th className="text-left p-3 text-muted-foreground font-medium uppercase tracking-wider text-[10px]">Direction</th>
                <th className="text-left p-3 text-muted-foreground font-medium uppercase tracking-wider text-[10px]">Accuracy</th>
                <th className="text-left p-3 text-muted-foreground font-medium uppercase tracking-wider text-[10px]">Risk</th>
                <th className="text-left p-3 text-muted-foreground font-medium uppercase tracking-wider text-[10px] hidden sm:table-cell">Strategy</th>
                <th className="text-left p-3 text-muted-foreground font-medium uppercase tracking-wider text-[10px]">Result</th>
              </tr>
            </thead>
            <tbody>
              {signalHistory.map((signal: TradingSignal, i: number) => (
                <tr key={signal.id || i} className="border-b border-[#1a2744]/50 hover:bg-white/3 transition-colors">
                  <td className="p-3 font-medium text-foreground">{signal.pair}</td>
                  <td className="p-3">
                    <span className={`inline-flex items-center gap-1 font-bold ${
                      signal.direction === 'BUY' ? 'text-[#22c55e]' : 'text-[#ef4444]'
                    }`}>
                      {signal.direction === 'BUY' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                      {signal.direction}
                    </span>
                  </td>
                  <td className="p-3">
                    <span className={`font-bold ${
                      signal.accuracy >= 80 ? 'text-[#22c55e]' : signal.accuracy >= 70 ? 'text-[#eab308]' : 'text-[#ef4444]'
                    }`}>
                      {signal.accuracy}%
                    </span>
                  </td>
                  <td className="p-3">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      signal.riskLevel === 'Low' ? 'risk-low' : signal.riskLevel === 'Medium' ? 'risk-medium' : 'risk-high'
                    }`}>
                      {signal.riskLevel}
                    </span>
                  </td>
                  <td className="p-3 text-muted-foreground hidden sm:table-cell">{signal.strategy}</td>
                  <td className="p-3">
                    <span className={`font-bold ${
                      signal.result === 'WIN' ? 'text-[#22c55e]' : 'text-[#ef4444]'
                    }`}>
                      {signal.result || 'Pending'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {signalHistory.length === 0 && (
          <div className="p-8 text-center text-muted-foreground text-sm">
            No signal history yet. Start trading to see your results.
          </div>
        )}
      </div>
    </div>
  );
}

// ==================== PRICING VIEW ====================
// Pricing and Auth views removed

// ==================== SETTINGS VIEW ====================
function SettingsView() {
  const { user, soundEnabled, toggleSound, autoRefresh, setAutoRefresh, refreshInterval, setRefreshInterval, token } = useAppStore();
  const [showApiKey, setShowApiKey] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedSecret, setCopiedSecret] = useState(false);

  const copyToClipboard = (text: string, type: 'key' | 'secret') => {
    navigator.clipboard.writeText(text);
    if (type === 'key') {
      setCopiedKey(true);
      setTimeout(() => setCopiedKey(false), 2000);
    } else {
      setCopiedSecret(true);
      setTimeout(() => setCopiedSecret(false), 2000);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <h2 className="text-lg sm:text-xl font-bold text-foreground">Settings</h2>

      {/* Profile */}
      <div className="glass-card rounded-2xl p-4 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#00d4ff] uppercase tracking-wider">
          <User size={16} />
          Profile
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Name</div>
            <div className="text-sm font-medium text-foreground">{user?.name || 'N/A'}</div>
          </div>
          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Email</div>
            <div className="text-sm font-medium text-foreground">{user?.email || 'N/A'}</div>
          </div>
          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Plan</div>
            <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider ${
              user?.plan === 'vip' ? 'risk-low' : user?.plan === 'pro' ? 'risk-medium' : 'glass-input'
            }`}>
              {user?.plan?.toUpperCase() || 'FREE'}
            </span>
          </div>
          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Member Since</div>
            <div className="text-sm font-medium text-foreground">
              {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
            </div>
          </div>
        </div>
      </div>

      {/* API Keys */}
      <div className="glass-card rounded-2xl p-4 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-[#a855f7] uppercase tracking-wider">
          <Key size={16} />
          API Keys (Auto Trading)
        </div>

        <div className="space-y-3">
          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1.5">API Key</div>
            <div className="flex items-center gap-2">
              <div className="flex-1 glass-input rounded-xl px-4 py-2.5 text-xs font-mono text-muted-foreground overflow-hidden">
                {showApiKey ? (user?.apiKey || 'N/A') : '•••••••••••••••••••••••••••••••'}
              </div>
              <button
                onClick={() => setShowApiKey(!showApiKey)}
                className="p-2.5 rounded-xl glass-input hover:border-[#00d4ff]/30 transition-all"
              >
                {showApiKey ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
              <button
                onClick={() => copyToClipboard(user?.apiKey || '', 'key')}
                className="p-2.5 rounded-xl glass-input hover:border-[#00d4ff]/30 transition-all"
              >
                {copiedKey ? <Check size={14} className="text-[#22c55e]" /> : <Copy size={14} />}
              </button>
            </div>
          </div>

          <div>
            <div className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1.5">Secret Key</div>
            <div className="flex items-center gap-2">
              <div className="flex-1 glass-input rounded-xl px-4 py-2.5 text-xs font-mono text-muted-foreground overflow-hidden">
                •••••••••••••••••••••••••••••••
              </div>
              <button
                onClick={() => copyToClipboard(user?.secretKey || '', 'secret')}
                className="p-2.5 rounded-xl glass-input hover:border-[#00d4ff]/30 transition-all"
              >
                {copiedSecret ? <Check size={14} className="text-[#22c55e]" /> : <Copy size={14} />}
              </button>
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-[#eab308]/5 border border-[#eab308]/20">
          <p className="text-[10px] text-[#eab308]">
            <span className="font-bold">Note:</span> API keys are used for auto-trading integration. Keep your secret key secure and never share it publicly.
          </p>
        </div>
      </div>

      {/* Preferences */}
      <div className="glass-card rounded-2xl p-4 sm:p-6 space-y-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-foreground uppercase tracking-wider">
          <Settings size={16} />
          Preferences
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-foreground">Sound Notifications</div>
              <div className="text-[10px] text-muted-foreground">Play sound on new signals</div>
            </div>
            <div
              onClick={toggleSound}
              className={`toggle-switch ${soundEnabled ? 'active' : ''}`}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium text-foreground">Auto-Refresh</div>
              <div className="text-[10px] text-muted-foreground">Automatically refresh signals</div>
            </div>
            <div
              onClick={() => setAutoRefresh(!autoRefresh)}
              className={`toggle-switch ${autoRefresh ? 'active' : ''}`}
            />
          </div>

          {autoRefresh && (
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-foreground">Refresh Interval</div>
                <div className="text-[10px] text-muted-foreground">Time between auto-refreshes</div>
              </div>
              <select
                value={refreshInterval}
                onChange={(e) => setRefreshInterval(Number(e.target.value))}
                className="glass-input glass-select rounded-xl px-3 py-2 text-xs pr-8"
              >
                <option value={10}>10s</option>
                <option value={30}>30s</option>
                <option value={60}>60s</option>
              </select>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ==================== TICKER BAR ====================
function TickerBar() {
  const tickerData = [
    { pair: 'BTC/USD', price: '67,250.00', change: '+2.4%', up: true, cat: 'crypto' },
    { pair: 'ETH/USD', price: '3,520.00', change: '+1.8%', up: true, cat: 'crypto' },
    { pair: 'SOL/USD', price: '148.50', change: '+3.2%', up: true, cat: 'crypto' },
    { pair: 'XRP/USD', price: '0.6250', change: '-0.9%', up: false, cat: 'crypto' },
    { pair: 'EUR/USD', price: '1.0856', change: '+0.12%', up: true, cat: 'forex' },
    { pair: 'GBP/USD', price: '1.2720', change: '-0.08%', up: false, cat: 'forex' },
    { pair: 'USD/JPY', price: '151.85', change: '-0.25%', up: false, cat: 'forex' },
    { pair: 'AUD/USD', price: '0.6580', change: '+0.18%', up: true, cat: 'forex' },
    { pair: 'XAU/USD', price: '2,345.50', change: '+0.85%', up: true, cat: 'commodity' },
    { pair: 'NAS100/USD', price: '18,520', change: '+0.55%', up: true, cat: 'index' },
    { pair: 'USD/CAD', price: '1.3620', change: '-0.05%', up: false, cat: 'forex' },
    { pair: 'BNB/USD', price: '585.00', change: '+1.1%', up: true, cat: 'crypto' },
  ];

  return (
    <div className="glass-card rounded-xl p-2 overflow-hidden">
      <div className="flex gap-6 ticker-scroll whitespace-nowrap">
        {tickerData.map((item, i) => (
          <div key={i} className="flex items-center gap-2 text-xs">
            <span className="font-bold text-foreground">{item.pair}</span>
            <span className="font-mono text-muted-foreground">{item.price}</span>
            <span className={item.up ? 'text-[#22c55e] font-bold' : 'text-[#ef4444] font-bold'}>
              {item.change}
            </span>
          </div>
        ))}
        {/* Duplicate for seamless scroll */}
        {tickerData.map((item, i) => (
          <div key={`dup-${i}`} className="flex items-center gap-2 text-xs">
            <span className="font-bold text-foreground">{item.pair}</span>
            <span className="font-mono text-muted-foreground">{item.price}</span>
            <span className={item.up ? 'text-[#22c55e] font-bold' : 'text-[#ef4444] font-bold'}>
              {item.change}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== MAIN PAGE ====================
export default function BinaryTradingBot() {
  const { currentView, autoRefresh, refreshInterval, setCurrentSignal, setIsGenerating, user, setToken, setUser } = useAppStore();
  const refreshTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Auto-refresh signals
  useEffect(() => {
    if (autoRefresh && currentView === 'signals') {
      refreshTimerRef.current = setInterval(async () => {
        try {
          const headers: Record<string, string> = { 'Content-Type': 'application/json' };
          const token = localStorage.getItem('yqt_token');
          if (token) headers['Authorization'] = `Bearer ${token}`;

          const res = await fetch('/api/signals/generate', {
            method: 'POST',
            headers,
            body: JSON.stringify({
              broker: useAppStore.getState().selectedBroker,
              pair: useAppStore.getState().selectedPair,
              timeframe: useAppStore.getState().selectedTimeframe,
              strategy: useAppStore.getState().selectedStrategy,
            }),
          });

          if (res.ok) {
            const signal = await res.json();
            setCurrentSignal(signal);
            setIsGenerating(false);
            if (useAppStore.getState().soundEnabled) {
              playSignalSound(signal.direction);
            }
          }
        } catch (e) {
          console.error('Auto-refresh error');
        }
      }, refreshInterval * 1000);
    }

    return () => {
      if (refreshTimerRef.current) {
        clearInterval(refreshTimerRef.current);
      }
    };
  }, [autoRefresh, refreshInterval, currentView, setCurrentSignal, setIsGenerating]);

  // Restore session
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedToken = localStorage.getItem('yqt_token');
      const savedUser = localStorage.getItem('yqt_user');
      if (savedToken && savedUser) {
        setToken(savedToken);
        try {
          setUser(JSON.parse(savedUser));
        } catch {
          localStorage.removeItem('yqt_user');
        }
      }
    }
  }, [setToken, setUser]);

  return (
    <div className="animated-bg">
      <Particles />
      <div className="grid-pattern fixed inset-0 pointer-events-none" />

      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Top Bar */}
        <div className="p-3 sm:p-4 lg:p-6">
          <div className="max-w-5xl mx-auto">
            <TickerBar />
          </div>
        </div>

        {/* Main Content */}
        <main className="flex-1 px-3 sm:px-4 lg:px-6 pb-6">
          <div className="max-w-5xl mx-auto space-y-4 sm:space-y-6">
            <Header />
            <Navigation />

            <div>
                {currentView === 'signals' && <SignalsView />}
                {currentView === 'dashboard' && <DashboardView />}
                {currentView === 'history' && <HistoryView />}
                {currentView === 'settings' && <SettingsView />}
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="p-3 sm:p-4 mt-auto">
          <div className="max-w-5xl mx-auto text-center">
            <div className="glass-card rounded-xl p-3">
              <div className="flex items-center justify-center gap-2 text-[10px] sm:text-xs text-muted-foreground">
                <Shield size={12} className="text-[#eab308]" />
                <span>Signal Only Bot — Reads live market data, does NOT execute trades. Trading involves risk.</span>
              </div>
              <div className="text-[10px] text-muted-foreground/50 mt-1">
                Binary Trading Bot · AI-Powered Trading Signals · © 2025
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
